import dgl
import torch as th
import numpy as np
import pandas as pd
import scipy.io as sio

def load(dataset):
    if dataset == 'Bdataset':
        return load_Bdataset()
    elif dataset == 'Cdataset':
        return load_Cdataset()
    else:
        raise ValueError('Only Bdataset and Cdataset are supported.')

def load_Bdataset():
    """
    加载 Bdataset
    """
    drug_drug_raw = pd.read_csv('./dataset/Bdataset/drug_drug_baseline.csv', header=None).values  # (Nr, Nr)
    disease_disease_raw = pd.read_csv('./dataset/Bdataset/disease_disease_baseline.csv', header=None).values
    drug_protein = pd.read_csv('./dataset/Bdataset/associations/drug_protein.csv')
    protein_protein = pd.read_csv('./dataset/Bdataset/interactions/protein_protein.csv')
    drug_disease = pd.read_csv('./dataset/Bdataset/associations/Bdataset.csv')
    disease_protein = pd.read_csv('./dataset/Bdataset/associations/protein_disease.csv')

    # 相似性矩阵（原始值，不进行 top‑K 稀疏化，稀疏化在 build_similarity_graph 中处理）
    drug_sim = drug_drug_raw.astype(np.float32)
    disease_sim = disease_disease_raw.astype(np.float32)

    graph_data = {
        ('drug', 'drug_disease', 'disease'): (
            th.tensor(drug_disease['Drug'].values, dtype=th.long),
            th.tensor(drug_disease['Disease'].values, dtype=th.long)
        ),
        ('disease', 'disease_drug', 'drug'): (
            th.tensor(drug_disease['Disease'].values, dtype=th.long),
            th.tensor(drug_disease['Drug'].values, dtype=th.long)
        ),
        ('drug', 'drug_protein', 'protein'): (
            th.tensor(drug_protein['Drug'].values, dtype=th.long),
            th.tensor(drug_protein['Protein'].values, dtype=th.long)
        ),
        ('protein', 'protein_drug', 'drug'): (
            th.tensor(drug_protein['Protein'].values, dtype=th.long),
            th.tensor(drug_protein['Drug'].values, dtype=th.long)
        ),
        ('protein', 'protein_disease', 'disease'): (
            th.tensor(disease_protein['Protein'].values, dtype=th.long),
            th.tensor(disease_protein['Disease'].values, dtype=th.long)
        ),
        ('disease', 'disease_protein', 'protein'): (
            th.tensor(disease_protein['Disease'].values, dtype=th.long),
            th.tensor(disease_protein['Protein'].values, dtype=th.long)
        ),
        ('protein', 'protein_protein', 'protein'): (
            th.tensor(protein_protein['Protein1'].values, dtype=th.long),
            th.tensor(protein_protein['Protein2'].values, dtype=th.long)
        ),
    }
    g = dgl.heterograph(graph_data)

    protein_feat = None
    try:
        esm = pd.read_csv('./dataset/Bdataset/Protein_ESM.csv', index_col=0)
        if esm.shape[0] == g.num_nodes('protein'):
            protein_feat = th.from_numpy(esm.values).float()
    except Exception:
        pass 

    return g, drug_sim, disease_sim, protein_feat

def load_Cdataset():
    """加载 Cdataset"""
    data = sio.loadmat('./dataset/Cdataset/Cdataset.mat')
    drug_disease = data['didr'].T
    disease_disease = data['disease']
    drug_drug = data['drug']

    drug_sim = drug_drug.astype(np.float32)
    disease_sim = disease_disease.astype(np.float32)

    # 构建异构图
    drug_disease = pd.DataFrame(np.array(np.where(drug_disease == 1)).T, columns=['Drug', 'Disease'])
    graph_data = {
        ('drug', 'drug_disease', 'disease'): (
            th.tensor(drug_disease['Drug'].values, dtype=th.long),
            th.tensor(drug_disease['Disease'].values, dtype=th.long)
        ),
        ('disease', 'disease_drug', 'drug'): (
            th.tensor(drug_disease['Disease'].values, dtype=th.long),
            th.tensor(drug_disease['Drug'].values, dtype=th.long)
        )
    }
    g = dgl.heterograph(graph_data)
    return g, drug_sim, disease_sim, None

def remove_graph(g, test_ids):
    test_drug = test_ids[:, 0]
    test_dis = test_ids[:, 1]

    edges = g.edge_ids(th.tensor(test_drug), th.tensor(test_dis), etype=('drug', 'drug_disease', 'disease'))

    edges = g.edge_ids(th.tensor(test_dis), th.tensor(test_drug), etype=('disease', 'disease_drug', 'drug'))
    g = dgl.remove_edges(g, edges, etype=('disease', 'disease_drug', 'drug'))
    return g