import datetime
import numpy as np
import torch
import random
import seaborn
import os
from sklearn.metrics import roc_curve, roc_auc_score, \
    precision_recall_curve, average_precision_score
import matplotlib.pyplot as plt
import torch.nn as nn
import torch.nn.functional as F
import dgl


def get_metrics_auc(real_score, predict_score):
    """计算 AUC 和 AUPR"""
    AUC = roc_auc_score(real_score, predict_score)
    AUPR = average_precision_score(real_score, predict_score)
    return AUC, AUPR


def get_metrics(real_score, predict_score):
    """
    计算全面的二分类性能指标，基于最佳 F1 阈值。
    返回: (AUC, AUPR, Accuracy, F1, Precision, Recall, Specificity)
    """

    real_score = np.asarray(real_score).flatten()
    predict_score = np.asarray(predict_score).flatten()


    if len(real_score) == 0 or len(predict_score) == 0:
        return 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0

    sorted_unique_score = np.sort(np.unique(predict_score))

    if len(sorted_unique_score) < 2:
        pred_binary = (predict_score >= 0.5).astype(int)
        tp = np.sum((real_score == 1) & (pred_binary == 1))
        fp = np.sum((real_score == 0) & (pred_binary == 1))
        fn = np.sum((real_score == 1) & (pred_binary == 0))
        tn = np.sum((real_score == 0) & (pred_binary == 0))
        total = tp + fp + fn + tn
        if total == 0:
            return 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
        accuracy = (tp + tn) / total
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        specificity = tn / (tn + fp) if (tn + fp) > 0 else 0.0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
        auc = roc_auc_score(real_score, predict_score)
        aupr = average_precision_score(real_score, predict_score)
        return auc, aupr, accuracy, f1, precision, recall, specificity


    percentiles = np.linspace(0, 100, 1000)
    thresholds = np.percentile(predict_score, percentiles)

    thresholds = np.unique(thresholds)

    thresholds = np.sort(np.concatenate([thresholds, [predict_score.min() - 1e-6, predict_score.max() + 1e-6]]))


    tp_list = []
    fp_list = []
    fn_list = []
    tn_list = []

    for th in thresholds:
        pred_binary = (predict_score >= th).astype(int)
        tp = np.sum((real_score == 1) & (pred_binary == 1))
        fp = np.sum((real_score == 0) & (pred_binary == 1))
        fn = np.sum((real_score == 1) & (pred_binary == 0))
        tn = np.sum((real_score == 0) & (pred_binary == 0))
        tp_list.append(tp)
        fp_list.append(fp)
        fn_list.append(fn)
        tn_list.append(tn)

    tp_list = np.array(tp_list, dtype=np.float64)
    fp_list = np.array(fp_list, dtype=np.float64)
    fn_list = np.array(fn_list, dtype=np.float64)
    tn_list = np.array(tn_list, dtype=np.float64)

    total = tp_list + fp_list + fn_list + tn_list
    accuracy_list = (tp_list + tn_list) / total
    precision_list = tp_list / (tp_list + fp_list + 1e-12)  # 避免除零
    recall_list = tp_list / (tp_list + fn_list + 1e-12)
    specificity_list = tn_list / (tn_list + fp_list + 1e-12)
    f1_score_list = 2 * precision_list * recall_list / (precision_list + recall_list + 1e-12)

    # 找到最佳 F1 对应的索引
    # 处理全为 NaN 的情况
    if np.isnan(f1_score_list).all():
        best_idx = 0
    else:
        f1_score_list_nan = np.nan_to_num(f1_score_list, nan=-1.0)
        best_idx = np.argmax(f1_score_list_nan)

    accuracy = accuracy_list[best_idx]
    f1_score = f1_score_list[best_idx]
    precision = precision_list[best_idx]
    recall = recall_list[best_idx]
    specificity = specificity_list[best_idx]

    auc = roc_auc_score(real_score, predict_score)
    aupr = average_precision_score(real_score, predict_score)

    return float(auc), float(aupr), float(accuracy), float(f1_score), float(precision), float(recall), float(specificity)


def set_seed(seed=0):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)


class EarlyStopping(object):
    def __init__(self, patience=10, saved_path='.'):
        dt = datetime.datetime.now()
        self.filename = os.path.join(saved_path, 'early_stop_{}_{:02d}-{:02d}-{:02d}.pth'.format(
            dt.date(), dt.hour, dt.minute, dt.second))
        self.patience = patience
        self.counter = 0
        self.best_loss = None
        self.early_stop = False

    def _to_scalar(self, value):
        if isinstance(value, torch.Tensor):
            return value.item()
        if isinstance(value, np.ndarray):
            if value.size == 1:
                return value.item()
            else:
                return float(value.mean())
        if isinstance(value, (np.floating, np.integer)):
            return float(value)
        try:
            return float(value)
        except (TypeError, ValueError):
            return value

    def step(self, loss, model=None):
        loss = self._to_scalar(loss)
        if self.best_loss is None or loss < self.best_loss:
            self.best_loss = loss
            if model is not None:
                self.save_checkpoint(model)
            self.counter = 0
        else:
            self.counter += 1
            if self.counter >= self.patience:
                self.early_stop = True
        return self.early_stop

    def save_checkpoint(self, model):
        torch.save(model.state_dict(), self.filename)


def plot_result_auc(args, label, predict, auc):
    seaborn.set_style()
    fpr, tpr, threshold = roc_curve(label, predict)
    plt.figure()
    lw = 2
    plt.figure(figsize=(8, 8))
    plt.plot(fpr, tpr, color='darkorange',
             lw=lw, label='ROC curve (area = %0.4f)' % auc)
    plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver operating characteristic example')
    plt.legend(loc='lower right')
    plt.grid()
    plt.savefig(os.path.join(args.saved_path, 'result_auc.png'))
    plt.clf()


def plot_result_aupr(args, label, predict, aupr):
    seaborn.set_style()
    precision, recall, thresholds = precision_recall_curve(label, predict)
    plt.figure()
    lw = 2
    plt.figure(figsize=(8, 8))
    plt.plot(precision, recall, color='darkorange',
             lw=lw, label='AUPR Score (area = %0.4f)' % aupr)
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title('Precision/Recall Curve')
    plt.legend(loc='lower right')
    plt.grid()
    plt.savefig(os.path.join(args.saved_path, 'result_aupr.png'))
    plt.clf()

def build_similarity_graph(sim_matrix, k=20):
    """从原始相似性矩阵构建稀疏无向图（top‑k 最近邻）"""
    if isinstance(sim_matrix, np.ndarray):
        sim_matrix = torch.tensor(sim_matrix, dtype=torch.float32)
    N = sim_matrix.shape[0]
    device = sim_matrix.device
    # 归一化
    sim = sim_matrix / (sim_matrix.norm(dim=1, keepdim=True) + 1e-8)
    sim = sim.clone()
    sim.fill_diagonal_(-float('inf'))
    topk_vals, topk_idx = torch.topk(sim, k, dim=1)
    src = []
    dst = []
    for i in range(N):
        for j in topk_idx[i]:
            src.append(i)
            dst.append(j.item())
    src = torch.tensor(src, dtype=torch.long, device=device)
    dst = torch.tensor(dst, dtype=torch.long, device=device)
    g = dgl.graph((src, dst), num_nodes=N)
    g = dgl.add_reverse_edges(g)
    return g


class InfoNCELoss(nn.Module):
    def __init__(self, temperature=0.5):
        super(InfoNCELoss, self).__init__()
        self.temperature = temperature

    def forward(self, z1, z2):
        z1 = F.normalize(z1, dim=1)
        z2 = F.normalize(z2, dim=1)
        sim = torch.mm(z1, z2.t()) / self.temperature
        labels = torch.arange(z1.size(0), device=z1.device)
        loss = F.cross_entropy(sim, labels)
        return loss