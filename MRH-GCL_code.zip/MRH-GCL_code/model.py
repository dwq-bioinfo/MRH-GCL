import torch
import torch.nn as nn
import torch.nn.functional as F
import dgl
import dgl.function as fn
from dgl.nn.pytorch import GraphConv, GATConv, HeteroGraphConv


# ---------- 全局 R‑GCN 层 ----------
class RGCNLayer(nn.Module):
    def __init__(self, in_feats, out_feats, rel_names, dropout=0.0, activation=None):
        super(RGCNLayer, self).__init__()
        self.in_feats = in_feats
        self.out_feats = out_feats
        self.rel_names = rel_names
        self.dropout = nn.Dropout(dropout)
        self.activation = activation

        self.weights = nn.ModuleDict({
            rel: nn.Linear(in_feats, out_feats, bias=False) for rel in rel_names
        })
        self.loop_weight = nn.Linear(in_feats, out_feats, bias=False)
        self.bias = nn.Parameter(torch.zeros(out_feats))

    def forward(self, g, h):
        with g.local_scope():
            outputs = {ntype: torch.zeros(g.num_nodes(ntype), self.out_feats, device=h[ntype].device)
                       for ntype in g.ntypes if ntype in h}
            for etype in self.rel_names:
                src_type, _, dst_type = g.to_canonical_etype(etype)
                if src_type not in h or dst_type not in h:
                    continue
                transformed = self.weights[etype](h[src_type])
                g.nodes[src_type].data['h'] = transformed
                g.update_all(fn.copy_u('h', 'm'), fn.sum('m', 'h'), etype=etype)
                outputs[dst_type] += g.nodes[dst_type].data['h']
            for ntype in g.ntypes:
                if ntype in h:
                    outputs[ntype] += self.loop_weight(h[ntype])
            for ntype in outputs:
                outputs[ntype] = outputs[ntype] + self.bias
                if self.activation is not None:
                    outputs[ntype] = self.activation(outputs[ntype])
                outputs[ntype] = self.dropout(outputs[ntype])
            return outputs


# ---------- 局部子图编码器 ----------
class HeteroSubgraphEncoder(nn.Module):
    def __init__(self, in_feats, out_feats, dropout=0.0):
        super(HeteroSubgraphEncoder, self).__init__()
        self.conv = GraphConv(in_feats, out_feats, allow_zero_in_degree=True)
        self.dropout = nn.Dropout(dropout)

    def forward(self, subgraph, h):
        hetero_conv = HeteroGraphConv({etype: self.conv for etype in subgraph.etypes}, aggregate='sum')
        out = hetero_conv(subgraph, h)
        for k in out:
            out[k] = self.dropout(out[k])
        return out


# ---------- 节点级语义注意力 ----------
class NodeSemanticAttention(nn.Module):
    """
    为每个节点独立计算多个源嵌入的注意力权重。
    输入: z 形状 (N, num_sources, d)
    输出: 加权融合后的嵌入 (N, d)
    """
    def __init__(self, in_feats, hidden_size=128):
        super(NodeSemanticAttention, self).__init__()
        self.attn = nn.Sequential(
            nn.Linear(in_feats, hidden_size),
            nn.Tanh(),
            nn.Linear(hidden_size, 1, bias=False)
        )

    def forward(self, z):
        # z: (N, S, d)
        scores = self.attn(z)          # (N, S, 1)
        scores = scores.squeeze(-1)    # (N, S)
        weights = F.softmax(scores, dim=1)  # (N, S)
        fused = torch.sum(weights.unsqueeze(-1) * z, dim=1)  # (N, d)
        return fused


# ---------- 主模型 MRH_GCL ----------
class MRH_GCL(nn.Module):
    def __init__(self, hidden_feats, num_rels, rel_names, ntypes,
                 num_drugs, num_diseases, protein_feat_dim=None,
                 dropout=0.0, temperature=0.5, k_neighbors=20):
        super(MRH_GCL, self).__init__()
        self.hidden_feats = hidden_feats
        self.ntypes = ntypes
        self.rel_names = rel_names
        self.temperature = temperature
        self.k_neighbors = k_neighbors

        
        self.drug_sim_proj = nn.Linear(num_drugs, hidden_feats, bias=False)
        self.disease_sim_proj = nn.Linear(num_diseases, hidden_feats, bias=False)
        
        self.hetero_proj_drug = nn.Linear(hidden_feats, hidden_feats, bias=False)
        self.hetero_proj_disease = nn.Linear(hidden_feats, hidden_feats, bias=False)

        # 蛋白质特征投影
        if protein_feat_dim is not None and protein_feat_dim > 0:
            if protein_feat_dim != hidden_feats:
                self.protein_proj = nn.Linear(protein_feat_dim, hidden_feats, bias=False)
            else:
                self.protein_proj = nn.Identity()
        else:
            self.protein_proj = None

        # ---------- 全局视图 ----------
        self.rgcn1 = RGCNLayer(hidden_feats, hidden_feats, rel_names, dropout, activation=nn.PReLU())
        self.rgcn2 = RGCNLayer(hidden_feats, hidden_feats, rel_names, dropout, activation=nn.PReLU())

        # ---------- 局部视图 ----------
        self.subgraph_encoder_rd = HeteroSubgraphEncoder(hidden_feats, hidden_feats, dropout)
        self.subgraph_encoder_rp = HeteroSubgraphEncoder(hidden_feats, hidden_feats, dropout)
        self.subgraph_encoder_pd = HeteroSubgraphEncoder(hidden_feats, hidden_feats, dropout)

        # 子图级节点注意力
        self.subgraph_attention = NodeSemanticAttention(hidden_feats, hidden_size=64)

        # 全局-局部融合（Softmax）
        self.fusion_mlp = nn.ModuleDict({
            ntype: nn.Sequential(
                nn.Linear(hidden_feats * 2, hidden_feats),
                nn.ReLU(),
                nn.Linear(hidden_feats, 2)  # 输出两个 logits，用于 softmax
            ) for ntype in ntypes
        })


        self.drug_gat = GATConv(hidden_feats, hidden_feats, num_heads=1, allow_zero_in_degree=True)
        self.disease_gat = GATConv(hidden_feats, hidden_feats, num_heads=1, allow_zero_in_degree=True)


        self.projection = nn.Sequential(
            nn.Linear(hidden_feats, hidden_feats),
            nn.ReLU(),
            nn.Linear(hidden_feats, hidden_feats)
        )


        self.decoder_W = nn.Parameter(torch.Tensor(hidden_feats, hidden_feats))
        nn.init.xavier_uniform_(self.decoder_W)

    def forward(self, g, features, drug_sim_graph, disease_sim_graph):
        """
        features : dict 包含：
            'drug_hetero' : (Nr, hidden_feats) 随机初始化
            'disease_hetero': (Nd, hidden_feats)
            'drug_sim' : (Nr, Nr) 相似性矩阵行向量（原始值）
            'disease_sim': (Nd, Nd)
            'protein_raw' : (Np, feat_dim) 或 None
        """
        device = g.device


        h_hetero = {}
        h_hetero['drug'] = self.hetero_proj_drug(features['drug_hetero'])
        h_hetero['disease'] = self.hetero_proj_disease(features['disease_hetero'])
        

        if features.get('protein_raw') is not None:
            if self.protein_proj is not None:
                h_hetero['protein'] = self.protein_proj(features['protein_raw'])
            else:
                h_hetero['protein'] = features['protein_raw']
        else:
            if 'protein' in g.ntypes:
                h_hetero['protein'] = torch.zeros(g.num_nodes('protein'), self.hidden_feats, device=device)


        # 2. 全局视图（两层 R‑GCN）
        h_global = self.rgcn1(g, h_hetero)
        h_global = self.rgcn2(g, h_global)

        # 3. 局部视图（三个子图）
        canonical_etypes = set(g.canonical_etypes)
        subgraph_etypes = {
            'drug_disease': [('drug', 'drug_disease', 'disease'), ('disease', 'disease_drug', 'drug')],
            'drug_protein': [('drug', 'drug_protein', 'protein'), ('protein', 'protein_drug', 'drug')],
            'protein_disease': [('protein', 'protein_disease', 'disease'), ('disease', 'disease_protein', 'protein')]
        }
        subgraphs = []
        subgraph_names = []
        for name, etypes in subgraph_etypes.items():
            exist_etypes = [e for e in etypes if e in canonical_etypes]
            if exist_etypes:
                subg = g.edge_type_subgraph(exist_etypes)
                subgraphs.append(subg)
                subgraph_names.append(name)

        encoder_map = {
            'drug_disease': self.subgraph_encoder_rd,
            'drug_protein': self.subgraph_encoder_rp,
            'protein_disease': self.subgraph_encoder_pd
        }
        subgraph_emb_dicts = []
        for name, subg in zip(subgraph_names, subgraphs):
            h_sub = {nt: h_global[nt] for nt in subg.ntypes if nt in h_global}
            if h_sub:
                emb_dict = encoder_map[name](subg, h_sub)
                subgraph_emb_dicts.append(emb_dict)

        # 节点级注意力融合
        h_local = {}
        for ntype in self.ntypes:
            ntype_embs = []
            for emb_dict in subgraph_emb_dicts:
                if ntype in emb_dict:
                    ntype_embs.append(emb_dict[ntype])
            if len(ntype_embs) > 0:
                stacked = torch.stack(ntype_embs, dim=1)  # (N, S, d)
                fused = self.subgraph_attention(stacked)
                h_local[ntype] = fused
            else:
                if ntype in h_global:
                    h_local[ntype] = h_global[ntype]
                else:
                    h_local[ntype] = torch.zeros(g.num_nodes(ntype), self.hidden_feats, device=device)

        # 4. 全局-局部融合
        h_fused = {}
        for ntype in self.ntypes:
            if ntype in h_global and ntype in h_local:
                concat = torch.cat([h_global[ntype], h_local[ntype]], dim=-1)  # (N, 2d)
                logits = self.fusion_mlp[ntype](concat)  # (N, 2)
                weights = F.softmax(logits, dim=-1)     # (N, 2)
                h_fused[ntype] = weights[:, 0:1] * h_global[ntype] + weights[:, 1:2] * h_local[ntype]
            elif ntype in h_global:
                h_fused[ntype] = h_global[ntype]
            else:
                h_fused[ntype] = torch.zeros(g.num_nodes(ntype), self.hidden_feats, device=device)

        drug_emb_global = h_fused['drug']
        disease_emb_global = h_fused['disease']

        # 5. 相似性视图编码（使用固定投影层）
        drug_sim_h = self.drug_sim_proj(features['drug_sim'])        # (Nr, d)
        disease_sim_h = self.disease_sim_proj(features['disease_sim'])  # (Nd, d)
        drug_emb_sim = self.drug_gat(drug_sim_graph, drug_sim_h).squeeze(1)
        disease_emb_sim = self.disease_gat(disease_sim_graph, disease_sim_h).squeeze(1)

        # 6. 投影到对比空间
        drug_emb_proj = self.projection(drug_emb_global)
        disease_emb_proj = self.projection(disease_emb_global)
        drug_sim_proj = self.projection(drug_emb_sim)
        disease_sim_proj = self.projection(disease_emb_sim)

        # 7. 解码预测
        score = torch.mm(torch.mm(drug_emb_global, self.decoder_W), disease_emb_global.t())

        return {
            'score': score,
            'drug_emb': drug_emb_proj,
            'disease_emb': disease_emb_proj,
            'drug_emb_sim': drug_sim_proj,
            'disease_emb_sim': disease_sim_proj
        }