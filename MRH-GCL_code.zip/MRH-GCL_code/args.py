import argparse

parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)

# 设备
parser.add_argument('-id', '--device_id', default='0', type=str, help='GPU id')

# 数据集
parser.add_argument('-da', '--dataset', type=str, choices=['Bdataset', 'Cdataset'], default='Bdataset',
                    help='Dataset name (only Bdataset and Cdataset are supported)')

# 保存路径
parser.add_argument('-sp', '--saved_path', type=str, default='result', help='Save directory')

# 随机种子
parser.add_argument('-se', '--seed', default=42, type=int, help='Random seed')

# 训练
parser.add_argument('-fo', '--nfold', default=10, type=int, help='K-fold')
parser.add_argument('-ep', '--epoch', default=2000, type=int, help='Max epochs')
parser.add_argument('-lr', '--learning_rate', default=0.001, type=float, help='Learning rate')
parser.add_argument('-wd', '--weight_decay', default=1e-5, type=float, help='Weight decay')
parser.add_argument('-pa', '--patience', default=300, type=int, help='Early stopping patience')


parser.add_argument('-hf', '--hidden_feats', default=256, type=int, help='Hidden dimension')
parser.add_argument('-dp', '--dropout', default=0.35, type=float, help='Dropout rate')
parser.add_argument('-k', '--k_neighbors', default=20, type=int,
                    help='Number of nearest neighbors for similarity graph sparsification')
parser.add_argument('-cl_temp', '--contrastive_temp', default=0.5, type=float,
                    help='Temperature for InfoNCE')
parser.add_argument('-cl_lambda', '--contrastive_lambda', default=0.15, type=float,
                    help='Weight of contrastive loss')

args = parser.parse_args()
args.saved_path = args.saved_path + '_' + str(args.seed)