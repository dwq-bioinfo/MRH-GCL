import os
import numpy as np
import pandas as pd
import torch as th
from sklearn.model_selection import KFold
from args import args
from load_data import load, remove_graph
from utils import get_metrics_auc, set_seed, plot_result_auc, \
    plot_result_aupr, EarlyStopping, get_metrics, build_similarity_graph, InfoNCELoss
from model import MRH_GCL

def train():
    print(args)
    os.makedirs(args.saved_path, exist_ok=True)

    device = th.device(f'cuda:{args.device_id}' if args.device_id else 'cpu')
    
    if args.device_id:
        print('Training on GPU')
    else:
        print('Training on CPU')

    # 读取药物-疾病关联矩阵
    if args.dataset in ['Bdataset']:
        df = pd.read_csv(f'./dataset/{args.dataset}/{args.dataset}_baseline.csv', header=None).values
    else:  # Cdataset
        import scipy.io as sio
        m = sio.loadmat('./dataset/Cdataset/Cdataset.mat')
        df = m['didr'].T
    Nr, Nd = df.shape

    # 构建所有样本列表
    data = np.array([[i, j, df[i, j]] for i in range(Nr) for j in range(Nd)])
    data_pos = data[data[:, -1] == 1]
    data_neg = data[data[:, -1] == 0]

    set_seed(args.seed)
    kf = KFold(n_splits=args.nfold, shuffle=True, random_state=args.seed)
    fold = 0
    model_paths = []
    test_indices = []
    feature_paths = []

    for (train_pos_idx, test_pos_idx), (train_neg_idx, test_neg_idx) in zip(kf.split(data_pos), kf.split(data_neg)):
        fold += 1
        print(f'\n{args.nfold}-Fold CV: Fold {fold}')

        train_pos_id = data_pos[train_pos_idx]
        test_pos_id = data_pos[test_pos_idx]
        train_neg_id = data_neg[train_neg_idx]
        test_neg_id = data_neg[test_neg_idx]

        mask_label = np.ones(df.shape)
        mask_label[test_pos_id[:, 0], test_pos_id[:, 1]] = 0
        mask_label[test_neg_id[:, 0], test_neg_id[:, 1]] = 0
        mask_train = np.where(mask_label == 1)
        mask_test = np.where(mask_label == 0)

        g, drug_sim, disease_sim, protein_esm = load(args.dataset)
        g = remove_graph(g, test_pos_id[:, :-1]).to(device)

        Nr = g.num_nodes('drug')
        Nd = g.num_nodes('disease')
        hidden = args.hidden_feats

        drug_hetero = th.randn(Nr, hidden, device=device)
        disease_hetero = th.randn(Nd, hidden, device=device)
        drug_sim_feat = th.from_numpy(drug_sim).float().to(device)
        disease_sim_feat = th.from_numpy(disease_sim).float().to(device)

        if 'protein' in g.ntypes:
            if protein_esm is not None:
                protein_raw = protein_esm.to(device)
            else:
                protein_raw = th.randn(g.num_nodes('protein'), hidden, device=device)
        else:
            protein_raw = None
            
        features = {
            'drug_hetero': drug_hetero,
            'disease_hetero': disease_hetero,
            'drug_sim': drug_sim_feat,
            'disease_sim': disease_sim_feat,
            'protein_raw': protein_raw
        }
        feature_path = os.path.join(args.saved_path, f'fold_{fold}_features.pt')
        th.save(features, feature_path)
        feature_paths.append(feature_path)

        drug_sim_graph = build_similarity_graph(drug_sim, k=args.k_neighbors).to(device)
        disease_sim_graph = build_similarity_graph(disease_sim, k=args.k_neighbors).to(device)
        label = th.tensor(df).float().to(device)


        protein_feat_dim = protein_esm.shape[1] if protein_esm is not None else None
        model = MRH_GCL(
            hidden_feats=args.hidden_feats,
            num_rels=len(g.etypes),
            rel_names=g.etypes,
            ntypes=g.ntypes,
            num_drugs=Nr,
            num_diseases=Nd,
            protein_feat_dim=protein_feat_dim,
            dropout=args.dropout,
            temperature=args.contrastive_temp,
            k_neighbors=args.k_neighbors
        ).to(device)

        optimizer = th.optim.Adam(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
        scheduler = th.optim.lr_scheduler.CyclicLR(optimizer, base_lr=0.1*args.learning_rate,
                                                   max_lr=args.learning_rate, step_size_up=20,
                                                   mode='triangular2', cycle_momentum=False)

        pos_weight = th.tensor(len(train_neg_id) / len(train_pos_id))
        criterion = th.nn.BCEWithLogitsLoss(pos_weight=pos_weight)
        contrastive_loss = InfoNCELoss(temperature=args.contrastive_temp)
        stopper = EarlyStopping(patience=args.patience, saved_path=args.saved_path)

        for epoch in range(1, args.epoch + 1):
            model.train()
            output = model(g, features, drug_sim_graph, disease_sim_graph)
            score = output['score']

            train_scores = score[mask_train[0], mask_train[1]]
            train_labels = label[mask_train[0], mask_train[1]]

            loss_sup = criterion(train_scores, train_labels)
            loss_cl = (contrastive_loss(output['drug_emb'], output['drug_emb_sim']) +
                       contrastive_loss(output['disease_emb'], output['disease_emb_sim'])) / 2
            total_loss = loss_sup + args.contrastive_lambda * loss_cl

            optimizer.zero_grad()
            total_loss.backward()
            th.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()
            scheduler.step()

            with th.no_grad():
                pred = th.sigmoid(score)
                train_auc, _ = get_metrics_auc(
                    label[mask_train[0], mask_train[1]].cpu().numpy(),
                    pred[mask_train[0], mask_train[1]].cpu().numpy()
                )

            if epoch % 100 == 0:
                current_lr = optimizer.param_groups[0]['lr']
                print(f'Epoch {epoch} Loss: {total_loss.item():.3f}; Train AUC {train_auc:.3f}')
                print('----------------------------------------------------------')   # 新增分隔线

            if stopper.step(total_loss.item(), model=model):
                break

        model_paths.append(stopper.filename)
        test_indices.append((test_pos_id, test_neg_id, mask_test))
        print(f'Fold {fold} completed, best model saved at {stopper.filename}')

    # ---------- 测试阶段 ----------
    print('\n' + '='*60)
    print('Starting testing phase...')
    pred_result = np.zeros(df.shape)

    for fold, (test_pos_id, test_neg_id, mask_test) in enumerate(test_indices, 1):
        print(f'\nTesting Fold {fold} ...')
        g, drug_sim, disease_sim, _ = load(args.dataset)
        g = remove_graph(g, test_pos_id[:, :-1]).to(device)

        features = th.load(feature_paths[fold-1])
        for k in features:
            if isinstance(features[k], th.Tensor):
                features[k] = features[k].to(device)

        drug_sim_graph = build_similarity_graph(drug_sim, k=args.k_neighbors).to(device)
        disease_sim_graph = build_similarity_graph(disease_sim, k=args.k_neighbors).to(device)
        label = th.tensor(df).float().to(device)

        Nr = g.num_nodes('drug')
        Nd = g.num_nodes('disease')
        protein_feat_dim = features['protein_raw'].shape[1] if features['protein_raw'] is not None else None
        model = MRH_GCL(
            hidden_feats=args.hidden_feats,
            num_rels=len(g.etypes),
            rel_names=g.etypes,
            ntypes=g.ntypes,
            num_drugs=Nr,
            num_diseases=Nd,
            protein_feat_dim=protein_feat_dim,
            dropout=args.dropout,
            temperature=args.contrastive_temp,
            k_neighbors=args.k_neighbors
        ).to(device)
        model.load_state_dict(th.load(model_paths[fold-1]))
        model.eval()

        with th.no_grad():
            output = model(g, features, drug_sim_graph, disease_sim_graph)
            score = output['score']
            pred = th.sigmoid(score).cpu().numpy()

        test_labels = label[mask_test[0], mask_test[1]].cpu().numpy()
        test_preds = pred[mask_test[0], mask_test[1]]
        auc, aupr = get_metrics_auc(test_labels, test_preds)
        print(f'Fold {fold} Test AUC: {auc:.4f}, AUPR: {aupr:.4f}')

        pred_result[test_pos_id[:, 0], test_pos_id[:, 1]] = pred[test_pos_id[:, 0], test_pos_id[:, 1]]
        pred_result[test_neg_id[:, 0], test_neg_id[:, 1]] = pred[test_neg_id[:, 0], test_neg_id[:, 1]]

    # 总体性能
    all_labels = df.flatten()
    all_preds = pred_result.flatten()
    auc, aupr, acc, f1, pre, rec, spe = get_metrics(all_labels, all_preds)
    print('\n' + '='*60)
    print('Overall Performance on All Folds:')
    print(f'AUC: {auc:.4f}, AUPR: {aupr:.4f}, Acc: {acc:.4f}, F1: {f1:.4f}')
    print(f'Precision: {pre:.4f}, Recall: {rec:.4f}, Specificity: {spe:.4f}')

    pd.DataFrame(pred_result).to_csv(os.path.join(args.saved_path, 'result.csv'), index=False, header=False)
    plot_result_auc(args, all_labels, all_preds, auc)
    plot_result_aupr(args, all_labels, all_preds, aupr)
    print(f'\nResults saved to {args.saved_path}')

if __name__ == '__main__':
    train()